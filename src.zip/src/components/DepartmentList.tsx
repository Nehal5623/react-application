import React, { useState } from 'react';
import { Checkbox, Collapse, List, ListItem, ListItemText } from '@mui/material';

interface Department {
  id: number;
  name: string;
  subDepartments: string[];
}

const DepartmentList: React.FC<{ departments: Department[] }> = ({ departments }) => {
  const [expanded, setExpanded] = useState<number | null>(null);

  const handleToggle = (index: number) => {
    if (expanded === index) {
      setExpanded(null);
    } else {
      setExpanded(index);
    }
  };

  return (
    <List>
      {departments.map((department, index) => (
        <React.Fragment key={department.id}>
          <ListItem button onClick={() => handleToggle(index)}>
            <Checkbox />
            <ListItemText primary={department.name} />
          </ListItem>
          <Collapse in={expanded === index} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              {department.subDepartments.map((subDepartment, subIndex) => (
                <ListItem key={`${department.id}-${subIndex}`} button>
                  <Checkbox />
                  <ListItemText primary={subDepartment} />
                </ListItem>
              ))}
            </List>
          </Collapse>
        </React.Fragment>
      ))}
    </List>
  );
};

export default DepartmentList;
