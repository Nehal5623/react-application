import React from 'react';
import { BrowserRouter as Router,Link, Routes, Route} from 'react-router-dom';
import FirstPage from "./pages/FirstPage";
import SecondPage from './pages/SecondPage';

import "./App.css";

const App : React.FC = () => {
  return (
    <>
      <Router>
        <div>
          <nav>
            <ul>
              <li>
                <Link to = "/">Home</Link>
                <Link to = "/firstpage">first Page</Link>
                <Link to = "/secondpage">Second page</Link>
              </li>
            </ul>
          </nav>
        </div>
        <Routes>
          <Route path = "/firstpage" element={< FirstPage />} />
          <Route path = "/secondpage" element={< SecondPage />} />
          <Route path = "/" element={< FirstPage />} />
        </Routes>
      </Router>
    </>
  );
};

export default App;

