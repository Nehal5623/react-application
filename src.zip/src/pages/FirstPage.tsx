import React, { useState,useLayoutEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, TextField } from '@mui/material';

const FirstPage: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const history = useNavigate();

  const handleSubmit = () => {
    // Save user details in localstorage
    localStorage.setItem('userDetails', JSON.stringify({ name, phone, email }));
    // Redirect to the second page
    history('/second-page');
  };
  useLayoutEffect (() => {
    // Check if user details are available in localstorage, redirect to the second page
    const userDetails = localStorage.getItem('userDetails');
    if (userDetails) {
      history('/second-page');
    }
  }, [history]);

  return (
    <div>
      <TextField label="Name" value={name} onChange={(e) => setName(e.target.value)} />
      <TextField label="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
      <TextField label="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <Button onClick={handleSubmit}>Submit</Button>
    </div>
  );
};

export default FirstPage;
