import React, { useEffect, useState } from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';
import DepartmentList from '../components/DepartmentList';
import "./style.css";

interface Post {
  userId: number;
  id: number;
  title: string;
  body: string;
}

interface Department {
    id: number;
    name: string;
    subDepartments: string[];
  }

const SecondPage: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);

  useEffect(() => {
    // Fetch data from the API
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then((response) => response.json())
      .then((data) => setPosts(data));
//Mock department data
      const mockDepartments: Department[] = [
        { id: 1, name: 'Department 1', subDepartments: ['Sub Dept 1', 'Sub Dept 2'] },
        { id: 2, name: 'Department 2', subDepartments: ['Sub Dept 3', 'Sub Dept 4'] },
      ];

      setDepartments(mockDepartments);
  }, []);

  

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'title', headerName: 'Title', width: 200 },
    { field: 'body', headerName: 'Body', width: 400 },
  ];

  return (
    <div>  
        <div className="datagrid">
        <DataGrid rows={posts} columns={columns}  />
      </div>
         <DepartmentList departments={departments} />
         </div>
      
   

 
  );
};

export default SecondPage;
